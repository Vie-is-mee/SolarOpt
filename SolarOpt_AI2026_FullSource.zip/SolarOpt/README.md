# SolarOpt Studio — AI 2026 Prototype

SolarOpt là nguyên mẫu hỗ trợ kỹ sư thiết kế điện mặt trời mái nhà theo cơ chế **hiểu dữ liệu → mô phỏng → tối ưu → kiểm chứng → thử tình huống bất lợi → tự phục hồi khi dữ liệu thay đổi**.

Phiên bản này được làm lại từ frontend demo ban đầu để loại bỏ phần lớn dữ liệu hard-code quan trọng và bổ sung backend chạy được bằng FastAPI.

## 1. Những gì đã có trong source này

### Frontend
- 5 bước: Thiết lập → Digital Roof → Thiết kế → Kiểm chứng → Tự phục hồi.
- Nhập ảnh/bản vẽ/PDF.
- Nhập vị trí địa lý, kích thước mái, hướng/độ nghiêng mái, khoảng lùi, ngân sách.
- **Nhập đầy đủ thông tin tấm pin:** hãng, model, công suất, kích thước, giá, Voc, Vmp, Imp.
- **Nhập/lấy dữ liệu bức xạ:** có thể nhập thủ công hoặc lấy từ PVGIS.
- **Thanh kéo giờ mặt trời:** 06:00–18:00, hiển thị cao độ và phương vị mặt trời.
- Chế độ trực quan: Bố trí / Bóng che / Bức xạ.
- Chỉnh vật cản và chiều cao vật cản.
- Hiển thị kết quả tối ưu, verification, stress test, dependency trace, minimal repair và version history.

### Backend
- `FastAPI` + SQLite.
- Gemini 2.5 Flash-Lite cho **Vision/OCR gợi ý** từ ảnh hoặc PDF (tùy chọn).
- Chế độ **demo fallback** khi chưa có Gemini API key để toàn bộ luồng vẫn chạy.
- Geometry bằng Shapely.
- Tối ưu bằng OR-Tools CP-SAT; có greedy fallback nếu chưa cài OR-Tools.
- Tính vị trí mặt trời bằng pvlib; có công thức fallback nếu chưa cài.
- Lấy dữ liệu PVGIS không cần API key.
- Mô phỏng bóng vật cản theo cao độ/phương vị mặt trời.
- Tối ưu panel dựa trên nhiều thời điểm đại diện trong năm (không phụ thuộc riêng thanh kéo giao diện).
- Verification Engine.
- 8 stress scenarios.
- Dependency Graph + selective invalidation.
- Impact-aware uncertainty: thử biên của dữ kiện chưa chắc và chỉ hỏi kỹ sư khi tác động đủ lớn.
- Minimal Repair: ưu tiên giữ vị trí panel cũ khi thiết kế vẫn hợp lệ.
- Version history trong SQLite.

## 2. Kiến trúc

```text
Browser / React
      |
      | REST API
      v
FastAPI Backend
  |-- Vision/OCR (Gemini 2.5 Flash-Lite, optional)
  |-- Digital Roof / Geometry (Shapely)
  |-- Solar position (pvlib)
  |-- PVGIS irradiance
  |-- Shadow engine
  |-- Panel optimizer (OR-Tools CP-SAT)
  |-- Verification Engine
  |-- Stress Engine
  |-- Dependency Graph
  |-- Minimal Repair
  `-- Version Store (SQLite)
```

**Nguyên tắc:** Gemini không quyết định một thiết kế "đúng" hay "sai". Mô hình chỉ hỗ trợ hiểu ảnh/bản vẽ. Hình học, tối ưu và kiểm chứng là các bước xác định, có thể truy vết.

## 3. Chạy trên Windows

Yêu cầu:
- Python 3.11+.
- Node.js 20+.

### Backend

Cách nhanh nhất:

```bat
run_backend.bat
```

Hoặc thủ công:

```bat
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
set PYTHONPATH=.
uvicorn app.main:app --reload --port 8000
```

Backend: `http://localhost:8000`

Swagger: `http://localhost:8000/docs`

### Frontend

Mở terminal thứ hai:

```bat
run_frontend.bat
```

Hoặc:

```bat
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

## 4. Gemini API key — để trống được

File:

```text
backend/.env
```

Nội dung:

```env
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash-lite
```

Nếu `GEMINI_API_KEY` trống, endpoint Vision dùng dữ liệu demo fallback và phần còn lại vẫn chạy.

Khi có key, chỉ cần điền:

```env
GEMINI_API_KEY=YOUR_KEY_HERE
```

**Không bao giờ** đưa key vào React, `localStorage`, commit GitHub hoặc quay video key.

## 5. Logic bức xạ và bóng che

- Người dùng nhập hoặc lấy `annual_irradiance_kwh_m2` từ PVGIS.
- Sản lượng tấm pin xấp xỉ:

```text
P(kWp) × Irradiance(kWh/m²/year) × Performance Ratio × (1 - shading loss)
```

- Thanh kéo giờ mặt trời chỉ phục vụ **trực quan hóa bóng theo thời điểm**.
- Khi tạo thiết kế, backend đánh giá bóng ở các mốc đại diện 09:00/12:00/15:00 tại xuân phân, hạ chí và đông chí để tránh việc layout thay đổi chỉ vì người dùng kéo thanh thời gian.

## 6. Logic tối ưu

Mỗi vị trí panel là biến nhị phân `x_i ∈ {0,1}`.

Ràng buộc MVP:
- Panel nằm trong vùng mái sau setback.
- Không giao vật cản + khoảng an toàn.
- Không vượt ngân sách.
- Lưới ứng viên được sinh không chồng lấn.

Objective chính dựa trên năng lượng kỳ vọng và mức bóng. Khi chạy repair, vị trí cũ hợp lệ được thêm **preservation bonus** để giảm số panel phải di chuyển.

## 7. Dependency Graph

Ví dụ khi đổi `obstacle_height`:

```text
obstacle_height
  -> shadow_map
  -> feasible_region
  -> layout
  -> energy / cost / electrical
  -> verification / ROI / report
```

Các node như `roof_geometry` hoặc metadata không liên quan được tái sử dụng.

## 8. Stress Test

Hiện có 8 scenario:
1. Base geometry.
2. Obstacle height +20%.
3. Obstacle height +30%.
4. Roof measurement -2%.
5. Panel dimension +1%.
6. Irradiance -15%.
7. Safety setback +15 cm.
8. Budget -15%.

Mỗi scenario được **tái thiết kế + verify thật**, không phải PASS/FAIL hard-code ở frontend.

## 9. Test backend

```bash
cd backend
PYTHONPATH=. pytest -q
```

Trong môi trường phát triển của gói source này, 2 test lõi đã chạy thành công. Nếu chưa cài OR-Tools, test dùng greedy fallback; trước video chính thức nên cài đầy đủ `requirements.txt` để dùng CP-SAT.

## 10. Thứ nên làm trước khi nộp cuộc thi

- Chạy `pip install -r requirements.txt` để bảo đảm OR-Tools/pvlib/google-genai hoạt động.
- Tạo Gemini API key và test Vision bằng ảnh thật.
- Thay ảnh demo bằng 3–5 case thật/được phép sử dụng.
- Chạy benchmark và lưu CSV/log.
- Chụp screenshot mới cho proposal từ chính phiên bản này.
- Cập nhật proposal: Gemini 2.5 Flash-Lite thay cho các mô-đun AI chưa thực sự dùng.
- Tạo `AI_RESOURCE_DECLARATION.pdf` từ file trong `docs/`.
- Không commit `.env` hoặc bất kỳ key nào.

## 11. Giới hạn hiện tại

- Prototype giả định mái phẳng/được biểu diễn trong hệ tọa độ 2D; chưa phải CAD/BIM đầy đủ.
- Geometry engine hiện ưu tiên mái chữ nhật cho demo tối ưu; Vision có thể nhận gợi ý vật cản nhưng kỹ sư phải chỉnh trước khi thiết kế.
- Công thức bóng là mô hình hình học MVP, chưa thay thế phần mềm mô phỏng quang học/chứng nhận kỹ thuật chuyên dụng.
- Chưa kiểm tra kết cấu, PCCC hoặc thay thế chữ ký kỹ sư.
- Dữ liệu miễn phí của Gemini có điều khoản riêng; không dùng bản vẽ mật của khách hàng trong free tier.

## 12. Tài liệu kèm theo

- `docs/ARCHITECTURE.md`
- `docs/AI_RESOURCE_DECLARATION.md`
- `docs/DEMO_SCRIPT_5MIN.md`
- `docs/BENCHMARK_PLAN.md`
