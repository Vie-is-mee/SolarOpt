import { useEffect, useMemo, useState } from 'react'
import { RoofCanvas } from './components/RoofCanvas'
import { api } from './services/api'
import type { DesignResult, Obstacle, PanelSpec, ProjectConfig, RepairResult, StressResult, SunPosition, VerifyResult, UncertaintyResult } from './types'

const panelPresets: PanelSpec[] = [
  {manufacturer:'LONGi', model:'Hi-MO 6 580W', width_m:1.134, height_m:2.278, power_w:580, price_vnd:4200000, voc_v:52.1, vmp_v:43.6, imp_a:13.3},
  {manufacturer:'Jinko', model:'Tiger Neo 585W', width_m:1.134, height_m:2.278, power_w:585, price_vnd:4400000, voc_v:52.8, vmp_v:44.1, imp_a:13.27},
  {manufacturer:'Canadian Solar', model:'TOPHiKu6 575W', width_m:1.134, height_m:2.278, power_w:575, price_vnd:4100000, voc_v:51.8, vmp_v:43.2, imp_a:13.31},
]

const initialConfig: ProjectConfig = {
  project_name:'SolarOpt Demo - UIT', latitude:10.7769, longitude:106.7009,
  roof_width_m:10, roof_height_m:8, roof_azimuth_deg:180, roof_tilt_deg:10,
  setback_m:0.35, panel_gap_m:0.08, obstacle_clearance_m:0.25,
  annual_irradiance_kwh_m2:1581, performance_ratio:0.82, budget_vnd:100000000,
}

const initialObstacles: Obstacle[] = [
  {id:'tank', label:'Bồn nước', x:5.5, y:3.3, width_m:1.3, depth_m:1.15, height_m:1.2, confidence:1, source:'demo'},
  {id:'vent', label:'Ống thông gió', x:2.2, y:5.1, width_m:0.65, depth_m:0.65, height_m:0.7, confidence:1, source:'demo'},
]

function money(v:number){ return `${(v/1_000_000).toFixed(1)} triệu` }
function fmt(v:number,d=1){ return new Intl.NumberFormat('vi-VN',{maximumFractionDigits:d}).format(v) }

function NumberField({label,value,onChange,step=0.1,min,unit}:{label:string;value:number;onChange:(v:number)=>void;step?:number;min?:number;unit?:string}){
  return <label className="field"><span>{label}</span><div className="input-with-unit"><input type="number" value={value} min={min} step={step} onChange={e=>onChange(Number(e.target.value))}/>{unit&&<b>{unit}</b>}</div></label>
}

function StatusPill({ok,label}:{ok:boolean;label:string}){ return <span className={`pill ${ok?'ok':'warn'}`}>{ok?'●':'○'} {label}</span> }

function App(){
  const [step,setStep]=useState(1)
  const [config,setConfig]=useState<ProjectConfig>(initialConfig)
  const [panel,setPanel]=useState<PanelSpec>(panelPresets[0])
  const [obstacles,setObstacles]=useState<Obstacle[]>(initialObstacles)
  const [sourceFile,setSourceFile]=useState<File|null>(null)
  const [sourcePreview,setSourcePreview]=useState<string>('/demo/anh-drone-mai-nha.svg')
  const [visionMsg,setVisionMsg]=useState('Chưa chạy AI. Có thể dùng hình học demo hoặc tải ảnh thật.')
  const [health,setHealth]=useState<{gemini_configured:boolean;gemini_model:string}|null>(null)
  const [date,setDate]=useState('2026-09-20')
  const [hour,setHour]=useState(11.5)
  const [sun,setSun]=useState<SunPosition|null>(null)
  const [designMode,setDesignMode]=useState<'layout'|'shadow'|'irradiance'>('layout')
  const [objective,setObjective]=useState<'max_energy'|'balanced'|'durability'>('balanced')
  const [design,setDesign]=useState<DesignResult|null>(null)
  const [verify,setVerify]=useState<VerifyResult|null>(null)
  const [stress,setStress]=useState<StressResult|null>(null)
  const [repair,setRepair]=useState<RepairResult|null>(null)
  const [newTankHeight,setNewTankHeight]=useState(1.8)
  const [busy,setBusy]=useState<string>('')
  const [error,setError]=useState('')
  const [versions,setVersions]=useState<any[]>([])
  const [uncertainty,setUncertainty]=useState<UncertaintyResult|null>(null)

  useEffect(()=>{ api.health().then(setHealth).catch(()=>setHealth(null)) },[])
  useEffect(()=>{
    const id=setTimeout(()=>{
      api.sunPosition(config.latitude,config.longitude,date,hour).then(setSun).catch(()=>{})
    },180)
    return ()=>clearTimeout(id)
  },[config.latitude,config.longitude,date,hour])

  const selectedObstacle=useMemo(()=>obstacles.find(o=>o.id==='tank') || obstacles[0],[obstacles])

  async function run<T>(name:string,fn:()=>Promise<T>,done:(x:T)=>void){
    setBusy(name);setError('')
    try{ done(await fn()) }catch(e:any){ setError(e?.message||String(e)) }finally{ setBusy('') }
  }

  function fileChanged(file:File|null){
    setSourceFile(file)
    if(file){
      if(sourcePreview.startsWith('blob:')) URL.revokeObjectURL(sourcePreview)
      if(file.type.startsWith('image/')) setSourcePreview(URL.createObjectURL(file))
      else setSourcePreview('/demo/ban-ve-ky-thuat.svg')
    }
  }

  async function analyze(){
    if(!sourceFile){ setVisionMsg('Bạn chưa chọn tệp. Đang giữ dữ liệu demo để không chặn luồng.'); return }
    await run('vision',()=>api.analyze(sourceFile),result=>{
      setConfig(c=>({...c,roof_width_m:result.roof_width_m,roof_height_m:result.roof_height_m}))
      setObstacles(result.obstacles.map(o=>({
        id:o.id,label:o.label,
        x:o.x_pct/100*result.roof_width_m,
        y:o.y_pct/100*result.roof_height_m,
        width_m:o.width_pct/100*result.roof_width_m,
        depth_m:o.depth_pct/100*result.roof_height_m,
        height_m:o.height_m,confidence:o.confidence,source:result.mode,
      })))
      setVisionMsg(`${result.mode==='gemini'?'Gemini':'Demo fallback'} · độ tin cậy mái ${(result.roof_confidence*100).toFixed(0)}%. ${result.notes.join(' ')}`)
    })
  }

  async function fetchIrradiance(){
    await run('irradiance',()=>api.irradiance(config.latitude,config.longitude,config.roof_tilt_deg,config.roof_azimuth_deg),r=>{
      setConfig(c=>({...c,annual_irradiance_kwh_m2:r.annual_irradiance_kwh_m2}))
      setVisionMsg(`Nguồn bức xạ: ${r.source}. ${r.detail}`)
    })
  }

  async function evaluateUncertainty(){
    const target=selectedObstacle
    if(!target) return
    const low=Math.max(0.1,target.height_m*0.8)
    const high=target.height_m*1.2
    await run('uncertainty',()=>api.uncertainty(config,panel,obstacles,target.id,low,high,objective),setUncertainty)
  }

  async function generate(){
    await run('design',()=>api.design(config,panel,obstacles,sun,objective),r=>{
      setDesign(r);setVerify(null);setStress(null);setRepair(null);setStep(3)
    })
  }

  async function verifyNow(){
    if(!design) return
    await run('verify',()=>api.verify(config,panel,obstacles,design,sun),setVerify)
  }

  async function stressNow(){
    if(!design) return
    await run('stress',()=>api.stress(config,panel,obstacles,design,sun),setStress)
  }

  async function repairNow(){
    if(!design||!selectedObstacle) return
    const after=obstacles.map(o=>o.id===selectedObstacle.id?{...o,height_m:newTankHeight}:o)
    await run('repair',()=>api.repair(config,panel,obstacles,after,design,sun,objective),r=>{
      setRepair(r)
      api.versions(config.project_name).then(setVersions).catch(()=>{})
    })
  }

  function applyRepair(){
    if(!repair||!selectedObstacle) return
    setObstacles(os=>os.map(o=>o.id===selectedObstacle.id?{...o,height_m:newTankHeight}:o))
    setDesign(repair.design);setVerify(repair.verification);setStress(null)
  }

  function exportSnapshot(){
    const payload={config,panel,obstacles,sun,design,verify,stress,repair,exported_at:new Date().toISOString()}
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url;a.download='solaropt-demo-snapshot.json';a.click();URL.revokeObjectURL(url)
  }

  const steps=[
    ['Thiết lập','Dữ liệu & linh kiện'],['Digital Roof','AI + chỉnh hình học'],['Thiết kế','Bóng che & bức xạ'],['Kiểm chứng','Stress test'],['Tự phục hồi','Trace impact & repair']
  ]

  return <div className="app-shell">
    <header className="topbar">
      <div><div className="brand">SolarOpt <span>Studio</span></div><div className="brand-sub">AI-assisted rooftop solar design · self-verifying · self-healing</div></div>
      <div className="header-actions">
        <StatusPill ok={!!health} label={health?'Backend online':'Backend offline'}/>
        <StatusPill ok={!!health?.gemini_configured} label={health?.gemini_configured?`${health?.gemini_model}`:'Gemini chưa cấu hình'}/>
        <button className="ghost" onClick={exportSnapshot}>Xuất snapshot</button>
      </div>
    </header>

    <nav className="stepper">
      {steps.map((s,i)=><button key={i} className={step===i+1?'active':''} onClick={()=>setStep(i+1)}>
        <b>{i+1}</b><span><strong>{s[0]}</strong><small>{s[1]}</small></span>
      </button>)}
    </nav>

    {error&&<div className="error-banner">{error}</div>}

    <main>
      {step===1&&<section className="page-grid">
        <div className="card wide">
          <div className="section-head"><div><span className="eyebrow">BƯỚC 1</span><h1>Tạo dự án và khai báo dữ liệu thật</h1><p>Phần này gom dữ liệu công trình, bức xạ và thông số tấm pin vào một hợp đồng dữ liệu duy nhất. API key không bao giờ nhập ở trình duyệt.</p></div></div>
          <div className="upload-row">
            <div className="upload-box">
              <img src={sourcePreview} alt="Nguồn dữ liệu mái"/>
              <label className="upload-button">Chọn ảnh / bản vẽ / PDF<input hidden type="file" accept="image/*,.pdf" onChange={e=>fileChanged(e.target.files?.[0]||null)}/></label>
              <small>{sourceFile?`${sourceFile.name} · ${(sourceFile.size/1024/1024).toFixed(2)} MB`:'Đang hiển thị ảnh demo đi kèm repository'}</small>
            </div>
            <div className="callout">
              <h3>Gemini Vision / OCR</h3><p>Gemini 2.5 Flash-Lite chỉ dùng để hiểu ảnh/bản vẽ và gợi ý vật cản. Hình học cuối cùng vẫn cho kỹ sư chỉnh và bộ tối ưu/kiểm chứng chạy bằng thuật toán xác định.</p>
              <button className="primary" disabled={busy==='vision'} onClick={analyze}>{busy==='vision'?'Đang phân tích…':'Phân tích ảnh bằng AI'}</button>
              <p className="tiny">{visionMsg}</p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2>Thông tin công trình</h2>
          <label className="field"><span>Tên dự án</span><input value={config.project_name} onChange={e=>setConfig({...config,project_name:e.target.value})}/></label>
          <div className="two"><NumberField label="Vĩ độ" value={config.latitude} step={0.0001} onChange={v=>setConfig({...config,latitude:v})}/><NumberField label="Kinh độ" value={config.longitude} step={0.0001} onChange={v=>setConfig({...config,longitude:v})}/></div>
          <div className="two"><NumberField label="Rộng mái" value={config.roof_width_m} unit="m" min={2} onChange={v=>setConfig({...config,roof_width_m:v})}/><NumberField label="Dài mái" value={config.roof_height_m} unit="m" min={2} onChange={v=>setConfig({...config,roof_height_m:v})}/></div>
          <div className="two"><NumberField label="Hướng mái" value={config.roof_azimuth_deg} unit="°" step={1} onChange={v=>setConfig({...config,roof_azimuth_deg:v})}/><NumberField label="Độ nghiêng" value={config.roof_tilt_deg} unit="°" step={1} onChange={v=>setConfig({...config,roof_tilt_deg:v})}/></div>
          <div className="two"><NumberField label="Khoảng lùi an toàn" value={config.setback_m} unit="m" step={0.05} onChange={v=>setConfig({...config,setback_m:v})}/><NumberField label="Khoảng hở panel" value={config.panel_gap_m} unit="m" step={0.01} onChange={v=>setConfig({...config,panel_gap_m:v})}/></div>
        </div>

        <div className="card">
          <div className="row-title"><h2>Bức xạ & bóng che</h2><button className="soft" disabled={busy==='irradiance'} onClick={fetchIrradiance}>{busy==='irradiance'?'Đang lấy…':'Lấy từ PVGIS'}</button></div>
          <NumberField label="Bức xạ năm trên mặt phẳng mái" value={config.annual_irradiance_kwh_m2} unit="kWh/m²/năm" step={1} onChange={v=>setConfig({...config,annual_irradiance_kwh_m2:v})}/>
          <NumberField label="Performance Ratio" value={config.performance_ratio} step={0.01} onChange={v=>setConfig({...config,performance_ratio:v})}/>
          <NumberField label="Khoảng cách vật cản" value={config.obstacle_clearance_m} unit="m" step={0.05} onChange={v=>setConfig({...config,obstacle_clearance_m:v})}/>
          <label className="field"><span>Ngày mô phỏng bóng</span><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
          <div className="slider-block"><div className="row-title"><span>Giờ mặt trời</span><b>{Math.floor(hour).toString().padStart(2,'0')}:{Math.round((hour%1)*60).toString().padStart(2,'0')}</b></div><input className="range" type="range" min="6" max="18" step="0.25" value={hour} onChange={e=>setHour(Number(e.target.value))}/><small>{sun?`Cao độ ${sun.altitude_deg.toFixed(1)}° · phương vị ${sun.azimuth_deg.toFixed(1)}°`:'Đang tính vị trí mặt trời…'}</small></div>
        </div>

        <div className="card wide">
          <h2>Thông tin tấm pin</h2>
          <div className="preset-row">{panelPresets.map(p=><button key={p.model} className={panel.model===p.model?'preset active':'preset'} onClick={()=>setPanel({...p})}><strong>{p.manufacturer}</strong><span>{p.model}</span><small>{p.power_w} W · {p.width_m}×{p.height_m} m</small></button>)}</div>
          <div className="panel-form">
            <label className="field"><span>Hãng</span><input value={panel.manufacturer} onChange={e=>setPanel({...panel,manufacturer:e.target.value})}/></label>
            <label className="field"><span>Model</span><input value={panel.model} onChange={e=>setPanel({...panel,model:e.target.value})}/></label>
            <NumberField label="Công suất" value={panel.power_w} unit="W" step={5} onChange={v=>setPanel({...panel,power_w:v})}/>
            <NumberField label="Rộng" value={panel.width_m} unit="m" step={0.001} onChange={v=>setPanel({...panel,width_m:v})}/>
            <NumberField label="Dài" value={panel.height_m} unit="m" step={0.001} onChange={v=>setPanel({...panel,height_m:v})}/>
            <NumberField label="Giá/tấm" value={panel.price_vnd} unit="VND" step={100000} onChange={v=>setPanel({...panel,price_vnd:v})}/>
            <NumberField label="Voc" value={panel.voc_v} unit="V" step={0.1} onChange={v=>setPanel({...panel,voc_v:v})}/>
            <NumberField label="Vmp" value={panel.vmp_v} unit="V" step={0.1} onChange={v=>setPanel({...panel,vmp_v:v})}/>
            <NumberField label="Imp" value={panel.imp_a} unit="A" step={0.1} onChange={v=>setPanel({...panel,imp_a:v})}/>
            <NumberField label="Ngân sách" value={config.budget_vnd} unit="VND" step={1000000} onChange={v=>setConfig({...config,budget_vnd:v})}/>
          </div>
          <div className="footer-actions"><button className="primary" onClick={()=>setStep(2)}>Tiếp tục tạo Digital Roof →</button></div>
        </div>
      </section>}

      {step===2&&<section className="page-grid">
        <div className="card wide">
          <div className="section-head"><div><span className="eyebrow">BƯỚC 2</span><h1>Digital Roof: mái, vật cản và mức chắc chắn</h1><p>AI chỉ gợi ý. Kỹ sư có thể chỉnh chiều cao/kích thước vật cản trước khi các bộ mô phỏng và tối ưu sử dụng dữ liệu.</p></div><button className="primary" onClick={()=>setStep(3)}>Sang thiết kế →</button></div>
          <RoofCanvas config={config} obstacles={obstacles} sun={sun}/>
        </div>
        <div className="card wide">
          <div className="row-title"><h2>Vật cản</h2><button className="soft" onClick={()=>setObstacles([...obstacles,{id:`obs-${Date.now()}`,label:'Vật cản mới',x:1,y:1,width_m:1,depth_m:1,height_m:1,confidence:1,source:'manual'}])}>+ Thêm vật cản</button></div>
          <div className="obstacle-table"><div className="tr head"><span>Tên</span><span>x</span><span>y</span><span>Rộng</span><span>Sâu</span><span>Cao</span><span>Tin cậy</span><span></span></div>{obstacles.map((o,idx)=><div className="tr" key={o.id}>
            <input value={o.label} onChange={e=>setObstacles(os=>os.map((x,i)=>i===idx?{...x,label:e.target.value}:x))}/>
            {(['x','y','width_m','depth_m','height_m'] as const).map(k=><input key={k} type="number" step="0.1" value={o[k]} onChange={e=>setObstacles(os=>os.map((x,i)=>i===idx?{...x,[k]:Number(e.target.value)}:x))}/>) }
            <span>{Math.round(o.confidence*100)}%</span><button className="danger-link" onClick={()=>setObstacles(os=>os.filter((_,i)=>i!==idx))}>Xóa</button>
          </div>)}</div>
          <div className="uncertainty-box">
            <div><h3>Impact-aware uncertainty</h3><p>Thử biên ±20% chiều cao của vật cản chính. SolarOpt chỉ hỏi kỹ sư nếu bất định làm thay đổi layout, năng lượng hoặc trạng thái hợp lệ đáng kể.</p></div>
            <button className="soft" disabled={busy==='uncertainty'||!selectedObstacle} onClick={evaluateUncertainty}>{busy==='uncertainty'?'Đang đánh giá…':'Đánh giá bất định'}</button>
          </div>
          {uncertainty&&<div className={`uncertainty-result ${uncertainty.action==='ASK_ENGINEER'?'ask':'auto'}`}><b>{uncertainty.action==='ASK_ENGINEER'?'CẦN KỸ SƯ XÁC NHẬN':'TỰ TIẾP TỤC'}</b><span>{uncertainty.explanation}</span><small>Impact score {uncertainty.impact_score} · layout Δ {uncertainty.layout_difference_pct}% · energy Δ {uncertainty.energy_difference_pct}%</small></div>}
        </div>
      </section>}

      {step===3&&<section className="page-grid">
        <div className="card wide">
          <div className="section-head"><div><span className="eyebrow">BƯỚC 3</span><h1>Thiết kế, bóng che và bức xạ</h1><p>Panel được sinh từ lưới vị trí khả thi và chọn bằng CP-SAT. Bóng che thay đổi theo thanh thời gian mặt trời.</p></div></div>
          <div className="design-toolbar">
            <div className="segmented">{(['layout','shadow','irradiance'] as const).map(m=><button key={m} className={designMode===m?'active':''} onClick={()=>setDesignMode(m)}>{m==='layout'?'Bố trí':m==='shadow'?'Bóng che':'Bức xạ'}</button>)}</div>
            <label>Ngày <input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
            <label className="time-control">☀ {Math.floor(hour).toString().padStart(2,'0')}:{Math.round((hour%1)*60).toString().padStart(2,'0')} <input type="range" min="6" max="18" step="0.25" value={hour} onChange={e=>setHour(Number(e.target.value))}/></label>
          </div>
          <RoofCanvas config={config} obstacles={obstacles} panels={design?.panels||[]} sun={sun} mode={designMode}/>
          <div className="legend"><span><i className="swatch panel"></i>Panel</span><span><i className="swatch obstacle"></i>Vật cản</span><span><i className="swatch shadow"></i>Bóng chiếu</span>{sun&&<span>Cao độ {sun.altitude_deg.toFixed(1)}° · phương vị {sun.azimuth_deg.toFixed(1)}°</span>}</div>
        </div>
        <div className="card">
          <h2>Tạo phương án</h2>
          <label className="field"><span>Mục tiêu</span><select value={objective} onChange={e=>setObjective(e.target.value as any)}><option value="max_energy">Tối đa sản lượng</option><option value="balanced">Cân bằng</option><option value="durability">Ưu tiên độ bền</option></select></label>
          <button className="primary full" disabled={busy==='design'} onClick={generate}>{busy==='design'?'Đang tối ưu…':'Chạy CP-SAT và mô phỏng'}</button>
          {design&&<div className="metric-grid">
            <div><small>Số tấm</small><strong>{design.metrics.panel_count}</strong></div><div><small>Công suất</small><strong>{design.metrics.peak_power_kwp} kWp</strong></div><div><small>Sản lượng</small><strong>{design.metrics.annual_energy_mwh} MWh/năm</strong></div><div><small>Chi phí</small><strong>{money(design.metrics.estimated_cost_vnd)}</strong></div><div><small>Mất do bóng</small><strong>{design.metrics.average_shading_loss_pct}%</strong></div><div><small>Diện tích mái dùng</small><strong>{design.metrics.roof_utilization_pct}%</strong></div>
          </div>}
          {design?.warnings.map(w=><div className="notice" key={w}>{w}</div>)}
          <div className="footer-actions"><button className="soft" disabled={!design} onClick={()=>setStep(4)}>Kiểm chứng →</button></div>
        </div>
        <div className="card">
          <h2>Giải thích kỹ thuật</h2>
          <ul className="facts"><li>Bức xạ đầu vào: <b>{fmt(config.annual_irradiance_kwh_m2,0)} kWh/m²/năm</b></li><li>PR: <b>{(config.performance_ratio*100).toFixed(0)}%</b></li><li>Setback: <b>{config.setback_m} m</b></li><li>Ngân sách: <b>{money(config.budget_vnd)}</b></li><li>Panel: <b>{panel.model}</b></li></ul>
          <p className="tiny">Trong chế độ bóng che, chiều dài bóng xấp xỉ h / tan(cao độ mặt trời). Bộ tối ưu loại vị trí bị che quá nặng tại thời điểm đang kiểm tra và giảm sản lượng kỳ vọng theo tỷ lệ giao bóng.</p>
        </div>
      </section>}

      {step===4&&<section className="page-grid">
        <div className="card wide">
          <div className="section-head"><div><span className="eyebrow">BƯỚC 4</span><h1>Kiểm chứng và thử tình huống bất lợi</h1><p>Thiết kế không được bàn giao ngay sau tối ưu. SolarOpt kiểm tra hình học, vật cản, ngân sách, dữ liệu điện và các tình huống biến động.</p></div><button className="primary" disabled={!design} onClick={()=>setStep(5)}>Tới tự phục hồi →</button></div>
          {!design&&<div className="empty">Hãy tạo một phương án ở Bước 3 trước.</div>}
          {design&&<div className="action-row"><button className="primary" disabled={busy==='verify'} onClick={verifyNow}>{busy==='verify'?'Đang kiểm…':'Chạy Verification Engine'}</button><button className="soft" disabled={busy==='stress'} onClick={stressNow}>{busy==='stress'?'Đang thử…':'Chạy 8 Stress Scenarios'}</button></div>}
        </div>
        {verify&&<div className="card wide"><div className="row-title"><h2>Verification</h2><span className={`score ${verify.valid?'good':'bad'}`}>{verify.valid?'PASS':'FAIL'}</span></div><div className="checks">{verify.checks.map(c=><div key={c.id} className={`check ${c.status.toLowerCase()}`}><b>{c.status}</b><span><strong>{c.label}</strong><small>{c.detail}</small></span></div>)}</div></div>}
        {stress&&<div className="card wide"><div className="row-title"><h2>Stress Test</h2><span className="score good">{stress.passed}/{stress.total}</span></div><div className="stress-grid">{stress.scenarios.map(s=><div key={s.id} className={`stress ${s.status.toLowerCase()}`}><div><b>{s.status}</b><strong>{s.name}</strong></div><small>{s.detail}</small><span>{s.panel_count} tấm · {(s.annual_energy_kwh/1000).toFixed(2)} MWh</span></div>)}</div></div>}
      </section>}

      {step===5&&<section className="page-grid">
        <div className="card wide"><div className="section-head"><div><span className="eyebrow">BƯỚC 5</span><h1>Tự phục hồi khi dữ liệu thay đổi</h1><p>Thay đổi chiều cao vật cản → lần theo đồ thị phụ thuộc → chỉ tính lại phần bị ảnh hưởng → ưu tiên giữ thiết kế cũ → kiểm chứng lại.</p></div></div>{!design&&<div className="empty">Hãy tạo thiết kế ở Bước 3 trước.</div>}</div>
        {design&&selectedObstacle&&<>
          <div className="card">
            <h2>Thay đổi hiện trường</h2>
            <div className="change-box"><span>{selectedObstacle.label}</span><strong>{selectedObstacle.height_m.toFixed(1)} m</strong><b>→</b><input type="number" step="0.1" value={newTankHeight} onChange={e=>setNewTankHeight(Number(e.target.value))}/><em>m</em></div>
            <button className="primary full" disabled={busy==='repair'} onClick={repairNow}>{busy==='repair'?'Đang trace & repair…':'Trace Impact + Minimal Repair'}</button>
          </div>
          <div className="card">
            <h2>Thiết kế trước thay đổi</h2><div className="metric-grid compact"><div><small>Panel</small><strong>{design.metrics.panel_count}</strong></div><div><small>Sản lượng</small><strong>{design.metrics.annual_energy_mwh} MWh</strong></div><div><small>Chi phí</small><strong>{money(design.metrics.estimated_cost_vnd)}</strong></div></div>
          </div>
          {repair&&<>
            <div className="card wide"><div className="row-title"><h2>Dependency Graph</h2><span className="score good">Tính lại {repair.impact.recomputation_ratio_pct}%</span></div><div className="impact-columns"><div><h3>Nodes bị ảnh hưởng</h3><div className="tags">{repair.impact.affected_nodes.map(n=><span className="tag affected" key={n}>{n}</span>)}</div></div><div><h3>Nodes được tái sử dụng</h3><div className="tags">{repair.impact.reused_nodes.map(n=><span className="tag reused" key={n}>{n}</span>)}</div></div></div></div>
            <div className="card wide"><div className="compare-title"><div><small>TRƯỚC</small><strong>{design.metrics.panel_count} tấm · {design.metrics.annual_energy_mwh} MWh</strong></div><span>→</span><div><small>SAU TỰ PHỤC HỒI</small><strong>{repair.design.metrics.panel_count} tấm · {repair.design.metrics.annual_energy_mwh} MWh</strong></div></div><div className="two-canvases"><RoofCanvas config={config} obstacles={obstacles} panels={design.panels} sun={sun} mode="shadow"/><RoofCanvas config={config} obstacles={obstacles.map(o=>o.id===selectedObstacle.id?{...o,height_m:newTankHeight}:o)} panels={repair.design.panels} sun={sun} mode="shadow"/></div><div className="metric-grid"><div><small>Panel giữ nguyên</small><strong>{repair.design.metrics.preserved_panel_count}</strong></div><div><small>Layout Preservation</small><strong>{repair.design.metrics.layout_preservation_rate_pct}%</strong></div><div><small>Verification</small><strong>{repair.verification.valid?'PASS':'FAIL'}</strong></div><div><small>Nodes tính lại</small><strong>{repair.impact.affected_nodes.length}</strong></div></div><div className="footer-actions"><button className="primary" onClick={applyRepair}>Chấp nhận phiên bản mới</button></div></div>
          </>}
          {versions.length>0&&<div className="card wide"><h2>Lịch sử phiên bản</h2><div className="version-list">{versions.slice(0,8).map(v=><div key={v.id}><b>#{v.id} · {v.version_label}</b><span>{v.reason}</span><small>{v.created_at}</small></div>)}</div></div>}
        </>}
      </section>}
    </main>

    <footer><span>SolarOpt prototype for AI 2026 · kỹ sư là người phê duyệt cuối</span><span>Không dùng để cấp chứng nhận kết cấu/PCCC</span></footer>
  </div>
}

export default App
