import type { CandidatePanel, Obstacle, ProjectConfig, SunPosition } from '../types'

function shadowPoints(o:Obstacle, sun:SunPosition|null, scaleX:number, scaleY:number) {
  if (!sun || sun.altitude_deg <= 1) return ''
  const alt = Math.max(1, sun.altitude_deg) * Math.PI / 180
  const az = sun.azimuth_deg * Math.PI / 180
  const length = Math.min(20, o.height_m / Math.tan(alt))
  const dx = -Math.sin(az) * length
  const dy = -Math.cos(az) * length
  const pts = [
    [o.x,o.y], [o.x+o.width_m,o.y], [o.x+o.width_m,o.y+o.depth_m], [o.x,o.y+o.depth_m],
    [o.x+dx,o.y+dy], [o.x+o.width_m+dx,o.y+dy], [o.x+o.width_m+dx,o.y+o.depth_m+dy], [o.x+dx,o.y+o.depth_m+dy],
  ]
  return pts.map(([x,y]) => `${x*scaleX},${(8-y)*scaleY}`).join(' ')
}

export function RoofCanvas({config, obstacles, panels=[], sun, mode='layout'}:{
  config:ProjectConfig; obstacles:Obstacle[]; panels?:CandidatePanel[]; sun:SunPosition|null; mode?:'layout'|'shadow'|'irradiance'
}) {
  const W=760,H=500,pad=34
  const sx=(W-2*pad)/config.roof_width_m
  const sy=(H-2*pad)/config.roof_height_m
  const toX=(x:number)=>pad+x*sx
  const toY=(y:number)=>H-pad-y*sy
  const energyVals=panels.map(p=>p.annual_energy_kwh)
  const minE=Math.min(...energyVals,0), maxE=Math.max(...energyVals,1)
  return <svg viewBox={`0 0 ${W} ${H}`} className="roof-canvas" role="img" aria-label="Digital Roof">
    <defs>
      <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M 24 0 L 0 0 0 24" fill="none" stroke="#dbe8df" strokeWidth="1"/></pattern>
      <linearGradient id="roofGrad" x1="0" x2="1"><stop offset="0" stopColor="#eff7f0"/><stop offset="1" stopColor="#e4f0e8"/></linearGradient>
    </defs>
    <rect x={pad} y={pad} width={config.roof_width_m*sx} height={config.roof_height_m*sy} rx="12" fill="url(#roofGrad)" stroke="#52715e" strokeWidth="3"/>
    <rect x={pad} y={pad} width={config.roof_width_m*sx} height={config.roof_height_m*sy} rx="12" fill="url(#grid)" opacity=".55"/>
    {mode==='shadow' && obstacles.map(o=>{
      if(!sun || sun.altitude_deg<=1) return null
      const alt=Math.max(1,sun.altitude_deg)*Math.PI/180
      const az=sun.azimuth_deg*Math.PI/180
      const L=Math.min(20,o.height_m/Math.tan(alt))
      const dx=-Math.sin(az)*L, dy=-Math.cos(az)*L
      const points=[[o.x,o.y],[o.x+o.width_m,o.y],[o.x+o.width_m,o.y+o.depth_m],[o.x,o.y+o.depth_m],[o.x+dx,o.y+dy],[o.x+o.width_m+dx,o.y+dy],[o.x+o.width_m+dx,o.y+o.depth_m+dy],[o.x+dx,o.y+o.depth_m+dy]]
        .map(([x,y])=>`${toX(x)},${toY(y)}`).join(' ')
      return <polygon key={`sh-${o.id}`} points={points} fill="#7f1d1d" opacity=".23" stroke="#991b1b" strokeDasharray="6 4"/>
    })}
    {panels.map((p,i)=>{
      const t=(p.annual_energy_kwh-minE)/Math.max(1,maxE-minE)
      const fill=mode==='irradiance' ? `hsl(${36+90*t} 58% ${48-8*t}%)` : p.preserved ? '#217a4c' : '#285f75'
      return <g key={p.id}>
        <rect x={toX(p.x)} y={toY(p.y+p.height_m)} width={p.width_m*sx} height={p.height_m*sy} rx="2" fill={fill} stroke="#123a49" strokeWidth="1.2"/>
        <line x1={toX(p.x)+p.width_m*sx/2} y1={toY(p.y+p.height_m)} x2={toX(p.x)+p.width_m*sx/2} y2={toY(p.y)} stroke="#d6f2ff" opacity=".7"/>
      </g>
    })}
    {obstacles.map(o=><g key={o.id}>
      <rect x={toX(o.x)} y={toY(o.y+o.depth_m)} width={o.width_m*sx} height={o.depth_m*sy} rx="4" fill="#c05a4d" stroke="#7d2d24" strokeWidth="2"/>
      <text x={toX(o.x)+4} y={toY(o.y+o.depth_m)+15} fontSize="11" fill="white" fontWeight="700">{o.label}</text>
      <text x={toX(o.x)+4} y={toY(o.y+o.depth_m)+29} fontSize="10" fill="#ffe8e4">{o.height_m.toFixed(1)} m</text>
    </g>)}
    {sun && <g>
      <circle cx={W-64} cy={55} r="22" fill="#f3c84d" stroke="#d9a919"/>
      <text x={W-122} y={93} fontSize="11" fill="#506054">☀ {sun.altitude_deg.toFixed(1)}° / {sun.azimuth_deg.toFixed(0)}°</text>
    </g>}
    <text x={pad} y={H-8} fontSize="11" fill="#738078">Mái {config.roof_width_m.toFixed(1)} × {config.roof_height_m.toFixed(1)} m · setback {config.setback_m.toFixed(2)} m</text>
  </svg>
}
