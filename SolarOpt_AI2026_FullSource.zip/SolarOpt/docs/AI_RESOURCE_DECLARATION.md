# BẢN KÊ KHAI CÔNG CỤ AI, DỮ LIỆU, API, THƯ VIỆN VÀ PHẦN ĐỘI TỰ XÂY DỰNG

> Bản nháp kỹ thuật. Trước khi nộp, đội cần đối chiếu đúng phiên bản package/API đang dùng và bổ sung link giấy phép nếu BTC yêu cầu.

| Thành phần | Loại | Mục đích trong SolarOpt | Phần đội tự làm / kiểm soát |
|---|---|---|---|
| Gemini 2.5 Flash-Lite | AI API | Đọc ảnh/bản vẽ, OCR gợi ý, vật cản | Prompt/schema, kiểm tra, chuyển sang Digital Roof, cho phép kỹ sư sửa; không dùng Gemini để quyết định PASS/FAIL |
| Google AI Studio | Dịch vụ cấp API key | Quản lý key/quota Gemini | Key chỉ lưu backend `.env` |
| PVGIS | API/dữ liệu công khai | Bức xạ trên mặt phẳng mái | Mapping vào ProjectConfig, fallback khi API lỗi |
| pvlib | Thư viện | Vị trí mặt trời | Lựa chọn thời điểm, tích hợp với shadow engine |
| Shapely | Mã nguồn mở | Hình học mái, vật cản, giao cắt | Digital Roof schema, ràng buộc, candidate generation |
| OR-Tools CP-SAT | Mã nguồn mở | Tối ưu chọn vị trí panel | Xây biến, ràng buộc, objective, Minimal Repair bonus |
| FastAPI | Mã nguồn mở | Backend API | Toàn bộ API contract và orchestration |
| React/Vite | Mã nguồn mở | Frontend | Toàn bộ SolarOpt Studio UX và visualization |
| SQLite | CSDL | Version history | Schema version và luồng lưu phiên bản |
| ChatGPT | Công cụ AI hỗ trợ phát triển | Nghiên cứu, rà soát kiến trúc, hỗ trợ mã và tài liệu | Đội đọc, kiểm tra, chạy test và chịu trách nhiệm cuối |

## Các phần cốt lõi do đội xây dựng

1. Data contract cho Digital Roof.
2. Pipeline dữ liệu từ ảnh/bản vẽ → geometry có thể chỉnh.
3. Candidate panel generation theo mái/ràng buộc.
4. Formulation tối ưu rooftop bằng CP-SAT.
5. Cơ chế ước lượng tổn thất bóng của prototype.
6. Verification Engine orchestration.
7. Bộ Stress Test có thể chạy lại thiết kế/verify.
8. Dependency Graph và selective invalidation.
9. Impact-aware uncertainty.
10. Minimal Repair / layout preservation.
11. Version history và giao diện Before/After/Trace Impact.

## Dữ liệu

- Ảnh/bản vẽ do đội tạo hoặc có quyền sử dụng cho demo.
- `sample_data/` chỉ phục vụ minh họa repository.
- Dữ liệu bức xạ lấy từ PVGIS khi người dùng yêu cầu.
- Không commit dữ liệu bản vẽ bí mật/nhạy cảm lên repository công khai.
