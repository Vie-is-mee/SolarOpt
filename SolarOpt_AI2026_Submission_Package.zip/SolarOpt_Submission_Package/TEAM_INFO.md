# THÔNG TIN ĐỘI Axiom

## Đội trưởng
**Nguyễn Võ An Vi**  
Trường Đại học Công nghệ Thông tin – ĐHQG TP.HCM  
Ngành: Khoa học Máy tính  
Lớp hành chính: KHMT 2024.4

## Thành viên
**Nguyễn Minh Triết**  
Trường Đại học Công nghệ Thông tin – ĐHQG TP.HCM  
Ngành: Khoa học Máy tính  
Lớp hành chính: KHMT 2024.4

**Trần Khôi Nguyên**  
Trường Đại học Công nghệ Thông tin – ĐHQG TP.HCM  
Ngành: Khoa học Máy tính  
Lớp hành chính: KHMT 2024.3

> Thông tin liên hệ chi tiết đã nằm trong hồ sơ dự án. Không cần phát tán thêm trong repository công khai nếu không cần thiết.
