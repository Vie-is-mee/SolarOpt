# KỊCH BẢN VIDEO THUYẾT TRÌNH SOLAROPT — TỐI ĐA 5 PHÚT

**Mục tiêu thời lượng:** 4 phút 35 giây – 4 phút 50 giây để có biên an toàn.

**Hình nền:** dùng chính proposal PDF, crop/zoom đúng khu vực đang nói. Không cần làm PowerPoint riêng. Không scroll toàn bộ PDF liên tục.

## 00:00–00:45 — Hook và bài toán

Xin chào Ban Giám khảo. Chúng em là đội Axiom đến từ Trường Đại học Công nghệ Thông tin – Đại học Quốc gia Thành phố Hồ Chí Minh.

Hãy tưởng tượng một hệ thống điện mặt trời mái nhà vừa được thiết kế xong. Nhưng khi kỹ sư ra hiện trường, chiều cao bồn nước không phải 1,2 mét như dữ liệu ban đầu mà là 1,8 mét.

Một thay đổi nhỏ như vậy có thể làm thay đổi bóng che, vùng có thể đặt tấm pin, bố trí hệ thống, sản lượng điện và hiệu quả tài chính.

Vấn đề chúng em muốn giải quyết không chỉ là AI có thể xếp tấm pin hay không, mà là: **khi thế giới thực thay đổi sau khi thiết kế đã hoàn thành, hệ thống có thể biết chính xác phần nào bị ảnh hưởng và tự sửa thiết kế hay không?**

## 00:45–01:20 — SolarOpt là gì?

Từ bài toán đó, chúng em phát triển **SolarOpt** – nền tảng AI hỗ trợ thiết kế điện mặt trời mái nhà theo cơ chế: **hiểu dữ liệu – mô phỏng – tối ưu – kiểm chứng – thử tình huống bất lợi – và tự phục hồi khi dữ liệu thay đổi.**

Người dùng có thể cung cấp bản vẽ, ảnh mái, ảnh hiện trường, vị trí công trình, thông tin tấm pin, ngân sách và điều kiện kỹ thuật. SolarOpt hợp nhất chúng thành **Digital Roof**, tức mô hình số có thể chỉnh sửa của mái gồm biên mái, vật cản, hướng mái và các vùng lắp đặt.

## 01:20–02:10 — AI và các bộ máy kỹ thuật

SolarOpt kết hợp AI với các thuật toán có thể kiểm chứng.

Gemini 2.5 Flash-Lite được sử dụng ở backend để hỗ trợ hiểu ảnh, đọc thông tin và gợi ý vật cản. Tuy nhiên, mô hình AI **không được quyền tự kết luận thiết kế đúng hay sai**.

Các phần quyết định kỹ thuật được tách thành những bộ máy xác định: xử lý hình học cho vùng lắp đặt; dữ liệu PVGIS và mô hình vị trí mặt trời cho bức xạ và bóng che; bộ tối ưu ràng buộc lựa chọn vị trí tấm pin; và Verification Engine kiểm tra biên mái, vật cản, khoảng cách an toàn, ngân sách cùng các ràng buộc khác.

Sau tối ưu, thiết kế còn được đưa qua các Stress Test để thử những tình huống như sai số kích thước, vật cản cao hơn, bức xạ giảm hoặc ngân sách thay đổi.

## 02:10–03:25 — Ba cơ chế khác biệt

Điểm khác biệt thứ nhất là **Dependency Graph – đồ thị phụ thuộc của dự án**.

Khi chiều cao bồn nước thay đổi, hệ thống biết các kết quả liên quan như bóng che, vùng khả thi, bố trí, sản lượng và chi phí phải được cập nhật, trong khi những phần không liên quan có thể được giữ lại. Mục tiêu là tránh chạy lại toàn bộ pipeline một cách không cần thiết.

Điểm thứ hai là **Minimal Repair – sửa tối thiểu**. SolarOpt không đơn giản xóa thiết kế cũ rồi tạo một bố trí hoàn toàn mới. Hệ thống ưu tiên giữ lại những tấm pin cũ vẫn hợp lệ và chỉ thay đổi phần thực sự cần thiết.

Điểm thứ ba là **Impact-aware Uncertainty – bất định có xét tác động**. SolarOpt không hỏi kỹ sư chỉ vì AI có độ tin cậy thấp. Hệ thống thử các giá trị biên của dữ kiện chưa chắc chắn; chỉ khi sự khác biệt có khả năng làm thay đổi bố trí, sản lượng hoặc trạng thái hợp lệ thì kỹ sư mới được yêu cầu xác nhận.

Nói cách khác, chúng em muốn AI biết **khi nào có thể tự xử lý và khi nào phải chuyển quyết định cho con người**.

## 03:25–04:08 — Nguyên mẫu sản phẩm

SolarOpt Studio hiện được tổ chức thành năm bước: **Thiết lập dự án, Hợp nhất dữ liệu, Thiết kế, Kiểm chứng và Bàn giao/Tự phục hồi**.

Ở không gian thiết kế, kỹ sư có thể xem bố trí, bóng che, bức xạ và kéo Solar Time Machine để quan sát thay đổi theo thời gian trong ngày. Kết quả thiết kế được đưa qua Verification và Stress Test trước khi kỹ sư duyệt.

Khi dữ liệu dự án thay đổi, giao diện Trace Impact cho biết phần nào bị ảnh hưởng; hệ thống tạo phiên bản thiết kế mới, so sánh Before/After và lưu lịch sử phiên bản. Video demo riêng của đội sẽ trình bày luồng này trực tiếp trên sản phẩm.

## 04:08–04:38 — Tác động

SolarOpt không được định vị để thay thế kỹ sư. Mục tiêu là chuyển các bước lặp lại, truy vết thay đổi và kiểm tra có thể tự động hóa sang hệ thống, để kỹ sư tập trung vào các quyết định kỹ thuật, an toàn và thương mại quan trọng.

Nếu giảm được công sức sửa thiết kế và giúp khai thác mái hiệu quả hơn, SolarOpt có thể hỗ trợ các đơn vị thiết kế và thi công xử lý nhiều dự án điện mặt trời hơn với cùng nguồn lực, qua đó tạo đồng thời giá trị kinh tế và hỗ trợ triển khai năng lượng sạch.

## 04:38–04:55 — Kết

Với SolarOpt, mục tiêu của chúng em không phải tạo ra một AI chỉ biết **thiết kế một lần**. Chúng em hướng tới một hệ thống có khả năng **duy trì một thiết kế hợp lệ khi thế giới thực liên tục thay đổi**, với kết quả có thể truy vết, kiểm chứng và luôn giữ kỹ sư ở vị trí phê duyệt cuối cùng.

Chúng em là đội Axiom. Xin cảm ơn Ban Giám khảo.

## Gợi ý hình proposal theo thời gian

- 00:00–00:45: trang đầu + mục Bài toán thực tiễn.
- 00:45–01:20: flow tổng quan SolarOpt.
- 01:20–02:10: kiến trúc AI/thuật toán.
- 02:10–03:25: Dependency Graph, Minimal Repair, Impact-aware Uncertainty.
- 03:25–04:08: 3–4 ảnh giao diện gốc đã đưa vào proposal.
- 04:08–04:38: tác động và khả năng triển khai.
- 04:38–04:55: trang kết/tên dự án.
