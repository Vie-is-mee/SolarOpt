# LỊCH SỬ CÂU LỆNH VÀ HÌNH ẢNH MINH CHỨNG

Cổng nộp hiện hiển thị mục này là **KHÔNG BẮT BUỘC**, nhưng đội nên cung cấp vì dự án sử dụng AI trong quá trình phát triển.

## Nguyên tắc quan trọng
- Chỉ dùng **lịch sử thật**.
- Không tự dựng lại prompt giả hoặc sửa timestamp để tạo cảm giác đã làm trước đó.
- Có thể loại bỏ dữ liệu cá nhân/API key/bí mật trước khi chia sẻ.
- Mở quyền xem cho BTC.

## Cấu trúc Google Drive đề xuất

```text
SolarOpt_AI2026_Evidence/
├── 01_Prompt_Log/
│   ├── ChatGPT_Proposal/
│   ├── ChatGPT_Source_Review/
│   ├── ChatGPT_Backend_Architecture/
│   └── Other_AI_if_used/
├── 02_UI_Development/
│   ├── early_frontend/
│   ├── digital_roof/
│   ├── design_space/
│   ├── verification/
│   └── self_healing/
├── 03_Code_Evidence/
│   ├── screenshots/
│   └── test_logs/
├── 04_Benchmark/
└── 05_Final_Product/
```

## Những nhóm prompt nên đưa vào
1. Xác định bài toán SolarOpt và pain point sửa thiết kế.
2. Thiết kế Digital Roof.
3. Dependency Graph / selective invalidation.
4. Minimal Repair.
5. Impact-aware uncertainty.
6. Thiết kế frontend 5 bước.
7. Rà soát backend/API.
8. Chuyển proposal sang Mẫu 3 Bảng C.
9. Rà soát tính nhất quán proposal ↔ source ↔ video.

## File INDEX.csv/Google Sheet đề xuất

Các cột:
- `date`
- `tool`
- `conversation_or_file`
- `purpose`
- `team_action_after_ai`
- `evidence_link`

Ví dụ phần `team_action_after_ai` nên ghi “đội kiểm tra, sửa và chạy test” thay vì chỉ ghi “AI tạo code”.

## Việc người dùng cần làm
- Export hoặc chụp lịch sử hội thoại thật.
- Đưa lên Drive.
- Xóa/che API key nếu có.
- Mở quyền xem.
- Điền link vào portal.
