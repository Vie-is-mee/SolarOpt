# SOLAROPT — CHECKLIST NỘP HỒ SƠ BẢNG C

> Dựa trên các mục hiển thị trên cổng nộp hồ sơ mà đội đã chụp lại. Các mục **BẮT BUỘC** trên cổng phải hoàn tất trước khi bấm nộp. Các mục không bắt buộc vẫn nên cung cấp nếu đã có vì chúng giúp hội đồng kiểm chứng mức độ làm chủ sản phẩm.

## A. Ba mục bắt buộc trên cổng

| Hạng mục | Trạng thái hiện tại | File/link cần nộp | Người xử lý tiếp |
|---|---|---|---|
| Tài liệu dự án PDF ≤20 trang | ✅ Đã có bản V4, 17 trang | `01_Proposal/SolarOpt_Proposal_Mau3_BangC.pdf` | Đội kiểm tra lần cuối rồi upload |
| Video thuyết trình ≤5 phút | 🟡 Script đã có, chưa quay | Drive/YouTube mở quyền xem | Nguyễn Võ An Vi/đội quay và upload |
| Video demo/trình diễn ≤5 phút | 🟡 Kịch bản bàn giao đã có, video chưa quay | Drive/YouTube mở quyền xem | Bạn phụ trách demo hoàn thiện source + quay |

## B. Các mục không bắt buộc trên màn hình cổng nộp nhưng nên chuẩn bị

| Hạng mục | Trạng thái | File đã chuẩn bị | Việc còn lại |
|---|---|---|---|
| Lịch sử câu lệnh và hình ảnh minh chứng | 🟡 Có hướng dẫn đóng gói | `04_Prompt_Log_Minh_Chung/PROMPT_LOG_GUIDE.md` | Đội xuất/chụp lịch sử thật, không dựng giả |
| Kê khai AI, dữ liệu, API, thư viện, mã nguồn mở | ✅ Nội dung đã soạn | `05_Ke_Khai_AI/AI_RESOURCE_DECLARATION_FINAL.md` | Đưa lên Drive/GitHub; rà đúng phiên bản dùng thật |
| Tài liệu/minh chứng kỹ thuật | ✅ Có bộ tài liệu | `06_Tai_Lieu_Ky_Thuat/` | Upload Drive hoặc dẫn GitHub repo |
| Công văn cử đội thi của Trường | ⚪ Không bắt buộc trên cổng | `08_Cong_Van_Cu_Doi/TODO_OPTIONAL.md` | Chỉ làm nếu đội chuyển sang diện Trường cử/đặc cách |

## C. Hạng mục đội đã nhắc trong yêu cầu thể lệ trước đó

### Giấy xác nhận sinh viên
Đội cần tự lấy giấy xác nhận còn đang học của 3 thành viên nếu cổng/thể lệ yêu cầu tại bước xác minh:
1. Nguyễn Võ An Vi — đội trưởng.
2. Nguyễn Minh Triết.
3. Trần Khôi Nguyên.

Xem `07_Giay_Xac_Nhan_Sinh_Vien/TODO_USER.md`.

### Kho mã nguồn
Source hiện được đóng gói riêng. Trước khi nộp nên đưa lên GitHub/GitLab, mở quyền phù hợp cho BTC và điền URL tại mục “Tài liệu/minh chứng kỹ thuật” nếu muốn.

## D. Quy tắc đồng bộ bắt buộc trước khi nộp

Mọi con số và chức năng xuất hiện trong 5 nơi sau phải khớp nhau:

```text
Proposal = Frontend = Backend = Video demo = README / Technical evidence
```

Đặc biệt kiểm tra:
- Kịch bản bồn nước 1,2 m → 1,8 m.
- Số tấm trước/sau.
- Sản lượng trước/sau.
- Stress Test.
- Dependency Graph / Trace Impact.
- Tên AI thật sự dùng: Gemini 2.5 Flash-Lite qua backend.
- Không để API key trong source/video.

## E. Việc còn do người dùng/đội thực hiện

1. Quay và upload **video thuyết trình**.
2. Hoàn thiện và quay **video demo**.
3. Tạo GitHub/GitLab và push source cuối.
4. Tạo Google Drive minh chứng + mở quyền xem.
5. Thu thập Prompt Log thật.
6. Xin giấy xác nhận sinh viên nếu được yêu cầu.
7. Điền các URL thật vào `PORTAL_LINKS_TEMPLATE.md`.
8. Test source trên máy đội bằng Miniconda trước khi công khai.
