# VIDEO DEMO ≤5 PHÚT — PHẦN ĐỘI/BẠN PHỤ TRÁCH DEMO THỰC HIỆN

## Mục tiêu
Không giới thiệu lý thuyết dài. Chứng minh sản phẩm có luồng end-to-end và các màn hình khớp với proposal/source.

## Kịch bản đề xuất

### 00:00–00:30 — Thiết lập
- Mở SolarOpt Studio.
- Tải một ảnh mái/bản vẽ demo được phép sử dụng.
- Chỉ nhanh vị trí, mái, panel/inverter, ngân sách.

### 00:30–01:10 — Digital Roof
- Chạy phân tích AI qua backend.
- Chỉ bồn nước/vật cản và confidence.
- Kéo/chỉnh một vật cản để thể hiện human-in-the-loop.

### 01:10–02:00 — Thiết kế
- Mở tab Bố trí.
- Chuyển Bóng che và Bức xạ.
- Kéo **Solar Time Machine** từ sáng → trưa → chiều.
- Chỉ “Vì sao đặt ở đây?”.

### 02:00–02:50 — Kiểm chứng
- So sánh các phương án.
- Cho thấy Verification/Stress Test.
- Nêu rõ kỹ sư duyệt cuối.

### 02:50–04:20 — Tự phục hồi
- Thay chiều cao bồn nước 1,2 m → 1,8 m.
- Chạy Trace Impact.
- Chạy Minimal Repair.
- So sánh Before/After.
- Cho thấy node bị ảnh hưởng vs node tái sử dụng.

### 04:20–05:00 — Phiên bản và kết
- Mở Version History.
- Nếu có report thì mở nhanh.
- Kết: AI hiểu dữ liệu; bộ tối ưu/kiểm chứng chạy theo quy tắc; kỹ sư phê duyệt cuối.

## Checklist trước khi quay
- [ ] Backend `http://127.0.0.1:8000/api/health` trả OK.
- [ ] Frontend ở `http://127.0.0.1:5173`.
- [ ] Không hiện API key trên màn hình.
- [ ] Source frontend giống ảnh trong proposal.
- [ ] Không còn tên GenD/DREAM/Arena trong repo/video.
- [ ] Không có lỗi console/terminal đỏ.
- [ ] File demo có quyền sử dụng.
- [ ] Video ≤5 phút và link mở được ở chế độ ẩn danh.

## Việc đội cần làm
Video này chưa thể tạo thay cho đội vì cần quay **bản chạy cuối cùng trên máy của đội**. Sau khi quay, upload Google Drive hoặc YouTube và điền URL vào `PORTAL_LINKS_TEMPLATE.md`.
