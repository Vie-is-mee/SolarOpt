# VIỆC ĐỘI CẦN LÀM — GIẤY XÁC NHẬN SINH VIÊN

Theo yêu cầu hồ sơ mà đội đã trích dẫn trước đó, hãy chuẩn bị giấy xác nhận còn đang học nếu BTC yêu cầu ở bước xác minh.

## Thành viên
1. **Nguyễn Võ An Vi** — đội trưởng — UIT — KHMT 2024.4.
2. **Nguyễn Minh Triết** — UIT — KHMT 2024.4.
3. **Trần Khôi Nguyên** — UIT — KHMT 2024.3.

## Cần làm
- Xin giấy xác nhận sinh viên còn hiệu lực của từng người hoặc loại giấy BTC chấp nhận.
- Scan/PDF rõ ràng.
- Kiểm tra tên, MSSV, trường và thời điểm xác nhận.
- Lưu vào Drive riêng của hồ sơ.

ChatGPT không thể tự xin hoặc ký giấy xác nhận thay cho thành viên/trường.
