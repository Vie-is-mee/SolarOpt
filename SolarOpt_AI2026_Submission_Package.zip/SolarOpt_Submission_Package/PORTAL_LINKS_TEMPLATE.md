# TEMPLATE LINK ĐIỀN LÊN CỔNG BTC

Điền sau khi upload xong và thử mở ở cửa sổ ẩn danh.

## Bắt buộc

**Video thuyết trình ≤5 phút**  
URL: `__________________________________________`

**Video demo / trình diễn ≤5 phút**  
URL: `__________________________________________`

## Không bắt buộc nhưng khuyến nghị

**Lịch sử câu lệnh và hình ảnh minh chứng — Drive folder**  
URL: `__________________________________________`

**Kê khai AI, dữ liệu, API, thư viện, mã nguồn mở**  
URL: `__________________________________________`

**Tài liệu / minh chứng kỹ thuật hoặc repository**  
URL: `__________________________________________`

**GitHub/GitLab source code**  
URL: `__________________________________________`

**Công văn cử đội thi của Trường (nếu có)**  
File/URL: `__________________________________________`

## Kiểm tra quyền trước khi lưu link
- [ ] Mở link ở tab ẩn danh.
- [ ] Không yêu cầu đăng nhập tài khoản cá nhân của đội.
- [ ] Không lộ file `.env`/API key.
- [ ] File/video đúng phiên bản cuối.
