# CÔNG VĂN CỬ ĐỘI THI CỦA TRƯỜNG — KHÔNG BẮT BUỘC TRÊN CỔNG HIỆN TẠI

Theo ảnh cổng nộp, mục này **KHÔNG BẮT BUỘC** và hệ thống ghi rõ có thể bổ sung sau; hồ sơ sẽ chuyển sang chờ Admin duyệt diện đội do Trường cử/đặc cách.

Nếu Axiom đăng ký theo diện đội tự do, không cần tạo công văn chỉ để lấp mục này.

Nếu đội muốn chuyển sang diện Trường cử:
1. Liên hệ đơn vị phụ trách của UIT.
2. Xin công văn PDF có xác nhận phù hợp.
3. Upload lên cổng theo hướng dẫn BTC.

ChatGPT không thể tạo một công văn giả hoặc chữ ký/con dấu của Trường.
